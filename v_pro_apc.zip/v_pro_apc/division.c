#include "apc.h"

void copy_head3_to_head1(Dlist**head1,Dlist**headR)
{
	Dlist*temp1 = *head1;
	Dlist*temp2 = *headR;
	while(temp1!=NULL)
	{
		temp1->data = temp2->data;
		temp1 = temp1->next;
		temp2 =temp2->next;
	}
}


int division(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR,Dlist **tailR)
{
	/* Definition goes here */
	if(check_len(head1,tail1,head2,tail2) == COUNT_2)
	{
	       printf("quotient : 0\n");
		   return 0;
	}
	Dlist *temp1 = *head1;
	Dlist *temp2 = *head2;
	int count = 0,n=10;
	while(1)
	{
		subtraction(head1,tail1,head2,tail2,headR,tailR);
		count++;
		copy_head3_to_head1(head1,headR);
		remove_zero(head1); 
		if(check_len(head1,tail1,head2,tail2)==COUNT_2)
		{
            printf("%d\n",count);
			return 0;
		}

	}
}
