#include "apc.h"

int delete_list(Dlist **head, Dlist **tail)
{
  if(*head == NULL)
  {
      return FAILURE;
  }
  if((*head)->next == NULL)
  {
      free((*head));
      *head = NULL;
      return SUCCESS;
  }
  *tail = (*tail)->prev;
  while(*head)
  {
      free((*tail)->next);
      (*tail) -> next = NULL;
      *tail = (*tail)->prev;
      if(*tail == NULL)
      {
        free((*head));
        (*head) = NULL;
        return SUCCESS;
      }
  }
  return FAILURE;
}