#include "apc.h"

void remove_zero(Dlist **head)
{
    Dlist *temp=*head;
    while(temp!=NULL)
    {
        if(temp->data > 0)
        {
            temp->prev = NULL;
            return;
        }
        if(temp->data == 0)
        {
            if(temp->next==NULL)
            {
                temp->prev = NULL;
                return;
            }
            *head = temp->next;

            free(temp);
            temp = *head;
        }
      //  temp = temp->next
    }
}