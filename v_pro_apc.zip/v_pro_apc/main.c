#include "apc.h"

int main(int argc,char *argv[])
{
	/* Declare the pointers */
      
	Dlist *head1=NULL, *tail1=NULL;
    Dlist *head2=NULL, *tail2=NULL; 
    Dlist *headR=NULL,*tailR=NULL;
    Dlist *temp = NULL;    

	char operator=argv[2][0];


		switch (operator)
		{
			case '+':
                                digit_to_list(&head1,&tail1,&head2,&tail2,argv);
				/* call the function to perform the addition operation */
                                addition(&head1,&tail1,&head2,&tail2,&headR,&tailR);
                                printf("--------------Addition----------------");
                                printf("\n\n%s %s %s = ",argv[1],argv[2],argv[3]);
								print_list(headR);
				break;
			case '-':	   
			          digit_to_list(&head1,&tail1,&head2,&tail2,argv);
				/* call the function to perform the subtraction operation */
				     subtraction(&head1,&tail1,&head2,&tail2,&headR,&tailR);
					 remove_zero(&headR); 
                      printf("--------------Subtraction----------------");
                      printf("\n\n%s %s %s = ",argv[1],argv[2],argv[3]);
                     if(check_len(&head1,&tail1,&head2,&tail2)==COUNT_2)
                     {
                        printf("-");
                     }
					 print_list(headR);	
				break;
			case 'x':	digit_to_list(&head1,&tail1,&head2,&tail2,argv);
				/* call the function to perform the multiplication operation */
                        multiplication(&head1,&tail1,&head2,&tail2,&headR,&tailR);
                        printf("--------------Multiplication----------------");
                        printf("\n\n%s %s %s = ",argv[1],argv[2],argv[3]);
                        print_list(headR);
				break;
			case '/':	
			         digit_to_list(&head1,&tail1,&head2,&tail2,argv);
				     /* call the function to perform the division operation */
                      printf("--------------Division----------------");
                      printf("\n\n%s %s %s = ",argv[1],argv[2],argv[3]);
				      division(&head1,&tail1,&head2,&tail2,&headR,&tailR);
					 // print_list(headR);
				break;
			default:
				printf("Invalid Input:-( Try again...\n");
		}
	return 0;
}
void digit_to_list(Dlist **head1,Dlist **tail1,Dlist **head2,Dlist **tail2,char *argv[])
{
    int i = 0;
	char *str1 = argv[1];   // Argument for first number is at argv[1] 
    while(str1[i] != '\0') 
	{
        insert_at_last(head1, tail1, str1[i] - '0');
		i++;
    }
	i=0;
    char *str2 = argv[3]; // Argument for second number is at argv[3] (after operator)
    while (str2[i]) 
	{
        insert_at_last(head2, tail2, str2[i] - '0'); 
		i++;
    }
}
void print_list(Dlist *head) {
    Dlist *temp = head;
    while (temp != NULL) {
        printf("%d", temp->data);
        temp = temp->next;
    }
	printf("\n");
}
int insert_at_last(Dlist **head, Dlist **tail, int data)
{
  Dlist *new = malloc(sizeof(Dlist));
  if(new == NULL)
  {
      return FAILURE;
  }
  new -> data = data;
  new -> next = NULL;
  new -> prev = *tail;
  if(*head == NULL)
  {
      *head = new;
      *tail = new;
      return SUCCESS;
  }
  (*tail)->next = new;
  *tail = new;
  return SUCCESS;
}
int insert_at_first(Dlist **head, Dlist **tail, int data)
{
 Dlist *new = malloc(sizeof(Dlist));
 if(new == NULL)
 {
     return FAILURE;
 }
 new -> data = data;
 new -> next = *head;
 new -> prev = NULL;
 if(*head == NULL)
 {
     *head = new;
     *tail = new;
     return SUCCESS;
 }
 (*head) -> prev = new;
 *head = new;
 return SUCCESS;
}


