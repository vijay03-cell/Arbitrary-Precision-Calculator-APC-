#include "apc.h"

int check_len(Dlist **head1,Dlist **tail1,Dlist **head2,Dlist **tail2)
{
    if(*head1 == NULL || *head2 == NULL)
    {
        return FAILURE;
    }
    int count1=0,count2=0;
    Dlist *temp1 = *head1,*temp2 = *head2;
    while(temp1 != NULL || temp2 != NULL)
    {
        if(temp1 != NULL)
        {
            temp1 = temp1 -> next;
            count1++;
        }
        if (temp2 != NULL)
        {
            temp2 = temp2 -> next;
            count2++;
        }
    }
    if(count1 < count2)
    {
        return COUNT_2;
    }
     else if (count1 > count2)
    {
        return COUNT_1;
    }
    temp1 = *head1;
    temp2 = *head2;
    while (temp1 != NULL && temp2 != NULL)
    {
        if (temp1->data < temp2->data)
        {
            return COUNT_2;
        }
        else if (temp1->data > temp2->data)
        {
            return COUNT_1;
        }
        temp1 = temp1->next;
        temp2 = temp2->next;
    }
    return COUNT_1;
}
