#include "apc.h"

int multiplication(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR,Dlist **tailR)
{
	Dlist *headr1=NULL,*tailr1=NULL,*headr2=NULL,*tailr2=NULL;
	Dlist *temp1=NULL,*temp2=NULL;
	temp1 = *tail1;
	temp2 = *tail2;
	int flag = 0;
	int carry = 0,data = 0,count=0;
	while(temp2 != NULL)
	{
       for(int i=0;i<count;i++)
	   {
          insert_at_first(&headr2,&tailr2,0);
	   }
		while(temp1 != NULL)
		{
			data = temp1->data * temp2->data + carry;
			carry = 0;
			if(data > 9)
			{
				carry = data / 10;
				data = data % 10;
			}
			if(temp2->next == NULL)
			{
				insert_at_first(&headr1,&tailr1,data);

			}
			else
			{
				insert_at_first(&headr2,&tailr2,data);
			}
        	temp1 = temp1->prev;
		}
		if(temp2->next != NULL)
	    {
			flag = 1;
			addition(&headr1,&tailr1,&headr2,&tailr2,headR,tailR);	
		    delete_list(&headr1,&tailr1);
			delete_list(&headr2,&tailr2);
			headr1 = *headR;
			tailr1 = *tailR;
	    }	    
		temp2 = temp2->prev;
		temp1 = *tail1;
		count++;
		if(temp2 == NULL)
		{
			if(flag==0)
			addition(&headr1,&tailr1,&headr2,&tailr2,headR,tailR);	
			if(carry>0)
			insert_at_first(headR,tailR,carry);
		}
	}
	return SUCCESS;
}

